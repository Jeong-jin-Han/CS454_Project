def sum_of_even(x: int) -> int:
    if x <= 0:
        return 0
    else:
        s = 0
        for i in range(x):
            if not (i % 2 == 1):
                s += i
        return s
