def tertiary(x:int, y:int)->int:
	if True if x == 42 else False:
		if 2 if y == 2007 else 0 == 2:
			return 1
		else: 
			return 2
	else:
		return 3